// src/pages/Login.js 

import React, { useState, useContext, useEffect } from 'react';
import AuthContext from '../contexts/AuthContext';
import './Login.css'; // 引入样式文件
import { useNavigate } from 'react-router-dom';
import { Box, TextField, Button, Typography, Snackbar, Alert } from '@mui/material';

const Login = () => {
  const { login } = useContext(AuthContext);
  const [credentials, setCredentials] = useState({ username: '', password: '' });
  const [rememberMe, setRememberMe] = useState(false);
  const [snackbar, setSnackbar] = useState({ open: false, message: '', severity: 'success' });
  const navigate = useNavigate();

  useEffect(() => {
    const savedUsername = localStorage.getItem('username');
    if (savedUsername) {
      setCredentials(prev => ({ ...prev, username: savedUsername }));
      setRememberMe(true);
      console.log('已保存用户名:', savedUsername);
    }
  }, []);

  const handleChange = (e) => {
    setCredentials(prev => ({ ...prev, [e.target.name]: e.target.value }));
  };

  const handleCheckboxChange = () => {
    setRememberMe(prev => !prev);
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    try {
      console.log('用户名:', credentials.username, '密码:', credentials.password); // 输出用户名和密码
      const response = await login(credentials.username, credentials.password); // 获取响应数据

      const { user } = response; // 获取用户信息
      console.log('登录响应中的用户:', user);

      if (rememberMe) {
        localStorage.setItem('username', credentials.username);
        console.log('用户名已保存到本地存储');
      } else {
        localStorage.removeItem('username');
        console.log('本地存储中的用户名已移除');
      }

      // 根据用户角色进行重定向
      if (user.roles && user.roles.includes('admin')) { // 检查是否包含 'admin' 角色
        console.log('用户具有管理员角色，重定向到 /admin');
        navigate('/admin'); // 跳转到管理员页面
      } else {
        console.log('用户不具有管理员角色，重定向到首页');
        navigate('/'); // 跳转到用户首页
      }
    } catch (error) {
      console.error('登录失败:', error);
      setSnackbar({ open: true, message: `登录失败: ${error.message}`, severity: 'error' });
    }
  };

  return (
    <Box
      component="form"
      onSubmit={handleSubmit}
      sx={{ display: 'flex', flexDirection: 'column', alignItems: 'center', mt: 8 }}
    >
      <Typography variant="h4" gutterBottom>登录</Typography>
      <TextField
        label="用户名"
        name="username"
        value={credentials.username}
        onChange={handleChange}
        required
        sx={{ mb: 2, width: '300px' }}
      />
      <TextField
        label="密码"
        name="password"
        type="password"
        value={credentials.password}
        onChange={handleChange}
        required
        sx={{ mb: 2, width: '300px' }}
      />
      <Box sx={{ display: 'flex', alignItems: 'center', mb: 2 }}>
        <input
          type="checkbox"
          checked={rememberMe}
          onChange={handleCheckboxChange}
          id="rememberMe"
        />
        <label htmlFor="rememberMe" style={{ marginLeft: '8px' }}>保存密码</label>
      </Box>
      <Button type="submit" variant="contained" color="primary">登录</Button>
      <Typography variant="body2" color="textSecondary" sx={{ mt: 2 }}>
        如忘记密码，请联系管理员
      </Typography>

      {/* Snackbar */}
      <Snackbar
        open={snackbar.open}
        autoHideDuration={6000}
        onClose={() => setSnackbar(prev => ({ ...prev, open: false }))}
        anchorOrigin={{ vertical: 'bottom', horizontal: 'center' }}
      >
        <Alert onClose={() => setSnackbar(prev => ({ ...prev, open: false }))}
               severity={snackbar.severity}
               sx={{ width: '100%' }}>
          {snackbar.message}
        </Alert>
      </Snackbar>
    </Box>
  );
};

export default Login;
