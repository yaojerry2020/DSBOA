// src/api.js

import axios from 'axios';

// 确认环境变量是否正确加载
console.log('API Base URL:', process.env.REACT_APP_API_URL);

// 创建一个Axios实例
const api = axios.create({
  baseURL: process.env.REACT_APP_API_URL,
  headers: {
    'Content-Type': 'application/json',
  },
  //withCredentials: true, // 如果后端使用 cookie 进行认证
});

// 添加请求拦截器，以自动添加Authorization头部
api.interceptors.request.use(
  (config) => {
    const token = localStorage.getItem('token'); // 获取存储的Token
    if (token) {
      config.headers['Authorization'] = `Bearer ${token}`; // 添加到请求头
    }
    return config;
  },
  (error) => Promise.reject(error)
);

export default api;
