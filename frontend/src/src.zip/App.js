// src/App.js

import React, { Suspense, lazy } from 'react';
import { ThemeProvider } from '@mui/material/styles';
import theme from './theme';
import { BrowserRouter as Router, Routes, Route, Navigate } from 'react-router-dom';
import { AuthProvider } from './contexts/AuthContext';
import PrivateRoute from './components/PrivateRoute';
import ErrorBoundary from './components/ErrorBoundary';

// 懒加载组件
const Login = lazy(() => import('./pages/Login'));
const AdminDashboard = lazy(() => import('./components/AdminDashboard'));
const UserManagement = lazy(() => import('./components/UserManagement'));
const DepartmentManagement = lazy(() => import('./components/DepartmentManagement'));
const EditDepartment = lazy(() => import('./components/EditDepartment'));
const CreateDepartment = lazy(() => import('./components/CreateDepartment'));
const RoleManagement = lazy(() => import('./components/RoleManagement'));
const CreateUser = lazy(() => import('./components/CreateUser'));
const EditUser = lazy(() => import('./components/EditUser'));

const App = () => {
  return (
    <ThemeProvider theme={theme}>
      <Router>
        <AuthProvider> {/* 将 AuthProvider 包裹在 Router 内部 */}
          <ErrorBoundary>
            <Suspense fallback={<div>加载中...</div>}>
              <Routes>
                {/* 登录路由 */}
                <Route path="/login" element={<Login />} />

                {/* 默认重定向到登录页 */}
                <Route path="/" element={<Navigate to="/login" />} />

                {/* 管理员路由，嵌套子路由 */}
                <Route
                  path="/admin"
                  element={<PrivateRoute element={<AdminDashboard />} roles={['admin']} />}
                >
                  {/* 用户管理 */}
                  <Route path="users" element={<UserManagement />} />

                  {/* 创建用户 */}
                  <Route path="users/create" element={<CreateUser />} />

                  {/* 编辑用户 */}
                  <Route path="users/edit/:id" element={<EditUser />} />

                  {/* 部门管理 */}
                  <Route path="departments" element={<DepartmentManagement />} />
                  <Route path="departments/create" element={<CreateDepartment />} />
                  <Route path="departments/edit/:id" element={<EditDepartment />} />

                  {/* 角色管理 */}
                  <Route path="roles" element={<RoleManagement />} />
                </Route>

                {/* 其他未匹配路由重定向到登录页 */}
                <Route path="*" element={<Navigate to="/login" />} />
              </Routes>
            </Suspense>
          </ErrorBoundary>
        </AuthProvider>
      </Router>
    </ThemeProvider>
  );
};

export default App;
