// src/contexts/AuthContext.js

import React, { createContext, useState, useEffect } from 'react';
import api from '../api';
import { useNavigate } from 'react-router-dom'; // 导入 useNavigate

const AuthContext = createContext();

export const AuthProvider = ({ children }) => {
  const navigate = useNavigate(); // 初始化 navigate
  const [user, setUser] = useState(null);
  const [token, setToken] = useState(null); // 如果需要存储 token
  const [loading, setLoading] = useState(true); // 添加加载状态

  // 初始化用户状态
  useEffect(() => {
    const storedToken = localStorage.getItem('token');
    if (storedToken) {
      setToken(storedToken);
      // 从后端获取用户信息
      api.get('/auth/me')
        .then(response => {
          setUser(response.data.user);
          console.log('用户已从存储中初始化:', response.data.user);
        })
        .catch(error => {
          console.error('获取用户信息失败:', error.response ? error.response.data : error.message);
          localStorage.removeItem('token');
          setUser(null);
        })
        .finally(() => {
          setLoading(false); // 无论成功或失败，结束加载状态
        });
    } else {
      setLoading(false); // 没有 token，结束加载状态
    }
  }, []);

  // 登录函数
  const login = async (username, password) => {
    try {
      const response = await api.post('/auth/login', { username, password });
      const data = response.data;
      const receivedToken = data.token;

      setUser(data.user);
      setToken(receivedToken);
      localStorage.setItem('token', receivedToken);

      console.log('登录成功:', data.user);
      return data; // 返回整个响应数据
    } catch (error) {
      console.error('登录请求错误:', error.response ? error.response.data : error.message);
      throw new Error(error.response?.data?.message || '登录失败');
    }
  };

  // 登出函数
  const logout = () => {
    setUser(null);
    setToken(null);
    localStorage.removeItem('token');
    console.log('用户已登出');
    navigate('/login'); // 登出后导航到登录页面
  };

  return (
    <AuthContext.Provider value={{ user, token, login, logout, loading }}>
      {children}
    </AuthContext.Provider>
  );
};

export default AuthContext;
