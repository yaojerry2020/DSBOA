// src/components/CreateUser.js

import React, { useEffect, useState } from 'react';
import api from '../api';
import { useNavigate } from 'react-router-dom';
import {
  TextField, Button, Paper, Typography,
  Grid, Alert, CircularProgress, FormControl,
  InputLabel, Select, OutlinedInput, Checkbox, MenuItem, ListItemText
} from '@mui/material';

const CreateUser = () => {
  const navigate = useNavigate();
  
  const [user, setUser] = useState({
    username: '',
    displayName: '',
    phone: '',
    email: '',
    departmentIds: [],
    roleIds: [],
    password: '',
  });
  
  const [departments, setDepartments] = useState([]);
  const [roles, setRoles] = useState([]);
  
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState('');
  
  useEffect(() => {
    fetchInitialData();
  }, []);
  
  const fetchInitialData = async () => {
    try {
      // 获取部门列表
      const departmentsResponse = await api.get('/admin/departments');
      const departmentsData = departmentsResponse.data;
      
      // 获取角色列表
      const rolesResponse = await api.get('/admin/roles');
      const rolesData = rolesResponse.data;
      
      setDepartments(departmentsData);
      setRoles(rolesData);
      setLoading(false);
    } catch (err) {
      console.error('获取数据失败:', err.response ? err.response.data : err.message);
      setError(err.response?.data?.message || '获取数据失败。');
      setLoading(false);
    }
  };
  
  const handleChange = (e) => {
    const { name, value } = e.target;
    setUser(prevState => ({
      ...prevState,
      [name]: value,
    }));
  };
  
  const handleChangeMultiple = (event, name) => {
    const {
      target: { value },
    } = event;
    setUser({
      ...user,
      [name]: typeof value === 'string' ? value.split(',') : value,
    });
  };
  
  const handleSubmit = async (e) => {
    e.preventDefault();
    setError('');
    try {
      // 构建创建的数据对象
      const createData = {
        username: user.username,
        displayName: user.displayName,
        phone: user.phone,
        email: user.email,
        roles: user.roleIds, // 后端期望的字段名
        departments: user.departmentIds, // 后端期望的字段名
        password: user.password,
      };
      
      await api.post('/admin/users', createData);
      alert('用户已创建。');
      navigate('/admin/users');
    } catch (err) {
      console.error('创建用户失败:', err.response ? err.response.data : err.message);
      setError(err.response?.data?.message || '创建用户失败。');
    }
  };
  
  if (loading) {
    return (
      <div style={{ textAlign: 'center', marginTop: '50px' }}>
        <CircularProgress />
        <Typography variant="h6">加载中...</Typography>
      </div>
    );
  }
  
  if (error) {
    return (
      <Paper style={{ padding: '20px', margin: '20px' }}>
        <Alert severity="error">{error}</Alert>
        <Button variant="contained" color="primary" onClick={() => navigate('/admin/users')} style={{ marginTop: '20px' }}>
          返回用户管理
        </Button>
      </Paper>
    );
  }
  
  return (
    <Paper style={{ padding: '20px', margin: '20px' }}>
      <Typography variant="h5" gutterBottom>新增用户</Typography>
      <form onSubmit={handleSubmit}>
        <Grid container spacing={2}>
          {/* 用户名 */}
          <Grid item xs={12} sm={6}>
            <TextField
              label="用户名"
              name="username"
              value={user.username}
              onChange={handleChange}
              fullWidth
              required
            />
          </Grid>
          {/* 显示名 */}
          <Grid item xs={12} sm={6}>
            <TextField
              label="显示名"
              name="displayName"
              value={user.displayName}
              onChange={handleChange}
              fullWidth
              required
            />
          </Grid>
          {/* 手机 */}
          <Grid item xs={12} sm={6}>
            <TextField
              label="手机"
              name="phone"
              value={user.phone}
              onChange={handleChange}
              fullWidth
            />
          </Grid>
          {/* 邮箱 */}
          <Grid item xs={12} sm={6}>
            <TextField
              label="邮箱"
              name="email"
              type="email"
              value={user.email}
              onChange={handleChange}
              fullWidth
            />
          </Grid>
          {/* 所在部门 - 多选 */}
          <Grid item xs={12} sm={6}>
            <FormControl fullWidth>
              <InputLabel id="departments-label">所在部门</InputLabel>
              <Select
                labelId="departments-label"
                label="所在部门"
                name="departmentIds"
                multiple
                value={user.departmentIds}
                onChange={(e) => handleChangeMultiple(e, 'departmentIds')}
                input={<OutlinedInput label="所在部门" />}
                renderValue={(selected) => selected.map(id => {
                  const dept = departments.find(d => d.id === id);
                  return dept ? dept.name : '';
                }).join(', ')}
              >
                {departments.map(dept => (
                  <MenuItem key={dept.id} value={dept.id}>
                    <Checkbox checked={user.departmentIds.indexOf(dept.id) > -1} />
                    <ListItemText primary={dept.name} />
                  </MenuItem>
                ))}
              </Select>
            </FormControl>
          </Grid>
          {/* 角色 - 多选 */}
          <Grid item xs={12} sm={6}>
            <FormControl fullWidth>
              <InputLabel id="roles-label">角色</InputLabel>
              <Select
                labelId="roles-label"
                label="角色"
                name="roleIds"
                multiple
                value={user.roleIds}
                onChange={(e) => handleChangeMultiple(e, 'roleIds')}
                input={<OutlinedInput label="角色" />}
                renderValue={(selected) => selected.map(id => {
                  const role = roles.find(r => r.id === id);
                  return role ? role.name : '';
                }).join(', ')}
              >
                {roles.map(role => (
                  <MenuItem key={role.id} value={role.id}>
                    <Checkbox checked={user.roleIds.indexOf(role.id) > -1} />
                    <ListItemText primary={role.name} />
                  </MenuItem>
                ))}
              </Select>
            </FormControl>
          </Grid>
          {/* 密码 */}
          <Grid item xs={12} sm={6}>
            <TextField
              label="密码"
              name="password"
              type="password"
              value={user.password}
              onChange={handleChange}
              fullWidth
              required
            />
          </Grid>
        </Grid>
        <div style={{ marginTop: '20px' }}>
          <Button type="submit" variant="contained" color="primary">
            创建
          </Button>
          <Button variant="outlined" color="secondary" onClick={() => navigate('/admin/users')} style={{ marginLeft: '10px' }}>
            取消
          </Button>
        </div>
      </form>
    </Paper>
  );
};

export default CreateUser;
