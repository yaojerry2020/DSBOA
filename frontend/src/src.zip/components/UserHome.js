// src/components/UserHome.js

import React from 'react';
import { Link } from 'react-router-dom';

const UserHome = () => {
  return (
    <div>
      <h2>用户主页</h2>
      <ul>
        <li><Link to="/home/profile">个人资料修改</Link></li>
        {/* 其他功能入口 */}
      </ul>
    </div>
  );
};

export default UserHome;
