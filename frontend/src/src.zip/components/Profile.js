// src/components/Profile.js

import React, { useState, useEffect, useContext } from 'react';
import { AuthContext } from '../contexts/AuthContext';

const Profile = () => {
  const { authTokens } = useContext(AuthContext);
  const [user, setUser] = useState(null);
  const [email, setEmail] = useState('');
  const [phone, setPhone] = useState('');
  const [password, setPassword] = useState('');
  const [message, setMessage] = useState('');

  useEffect(() => {
    const fetchUser = async () => {
      const response = await fetch('/user/me', { // 确保 API URL 正确
        method: 'GET',
        headers: {
          'Authorization': `Bearer ${authTokens}`,
          'Content-Type': 'application/json',
        },
      });
      const data = await response.json();
      if (response.ok) {
        setUser(data);
        setEmail(data.email || '');
        setPhone(data.phone || '');
      }
    };
    fetchUser();
  }, [authTokens]);

  const handleUpdate = async (e) => {
    e.preventDefault();
    const body = { email, phone };
    if (password) body.password = password;

    const response = await fetch('/user/me', { // 确保 API URL 正确
      method: 'PUT',
      headers: {
        'Authorization': `Bearer ${authTokens}`,
        'Content-Type': 'application/json',
      },
      body: JSON.stringify(body),
    });

    const data = await response.json();

    if (response.ok) {
      setMessage('信息更新成功。');
      setPassword('');
    } else {
      setMessage(data.message || '更新失败');
    }
  };

  if (!user) return <div>加载中...</div>;

  return (
    <div>
      <h2>个人资料修改</h2>
      {message && <p>{message}</p>}
      <form onSubmit={handleUpdate}>
        <div>
          <label>邮箱:</label>
          <input 
            type="email" 
            value={email} 
            onChange={(e) => setEmail(e.target.value)} 
            placeholder="邮箱可以为空"
          />
        </div>
        <div>
          <label>电话:</label>
          <input 
            type="text" 
            value={phone} 
            onChange={(e) => setPhone(e.target.value)} 
            required 
          />
        </div>
        <div>
          <label>新密码:</label>
          <input 
            type="password" 
            value={password} 
            onChange={(e) => setPassword(e.target.value)} 
            placeholder="留空则不修改密码"
          />
        </div>
        <button type="submit">更新信息</button>
      </form>
    </div>
  );
};

export default Profile;
