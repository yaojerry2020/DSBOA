// src/components/PrivateRoute.js

import React, { useContext } from 'react';
import { Navigate } from 'react-router-dom';
import AuthContext from '../contexts/AuthContext';
import { CircularProgress, Box } from '@mui/material';

const PrivateRoute = ({ element, roles }) => {
  const { user, loading } = useContext(AuthContext);

  if (loading) {
    // 在验证认证状态时显示加载指示器
    return (
      <Box sx={{ display: 'flex', justifyContent: 'center', alignItems: 'center', height: '100vh' }}>
        <CircularProgress />
      </Box>
    );
  }

  if (!user) {
    // 如果未认证，重定向到登录页
    return <Navigate to="/login" replace />;
  }

  if (roles && !roles.some(role => user.roles.includes(role))) {
    // 如果用户没有所需的角色，重定向到首页或显示无权限信息
    return <Navigate to="/" replace />;
  }

  // 如果通过验证，渲染指定的组件
  return element;
};

export default PrivateRoute;
