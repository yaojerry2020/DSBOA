// src/components/UserManagement.js

import React, { useState, useEffect } from 'react';
import {
  Box,
  Button,
  Table,
  TableBody,
  TableCell,
  TableContainer,
  TableHead,
  TableRow,
  Paper,
  Snackbar,
  Alert,
  IconButton
} from '@mui/material';
import { Edit, Delete } from '@mui/icons-material';
import api from '../api'; // 确保导入 axios 实例
import { useNavigate } from 'react-router-dom'; // 添加这一行

const UserManagement = () => {
  const [users, setUsers] = useState([]);
  const [snackbar, setSnackbar] = useState({ open: false, message: '', severity: 'success' });

  const navigate = useNavigate(); // 添加这一行

  const fetchUsers = async () => {
    try {
      const response = await api.get('/admin/users'); // 确保调用正确的 API 路径
      console.log('Fetched users:', response.data); // 添加日志
      setUsers(response.data);
    } catch (error) {
      console.error('获取用户数据失败:', error);
      setSnackbar({ open: true, message: '获取用户数据失败。', severity: 'error' });
    }
  };

  useEffect(() => {
    fetchUsers();
  }, []);

  const handleDelete = async (id) => {
    try {
      await api.delete(`/api/admin/users/${id}`);
      setUsers(users.filter(user => user.id !== id));
      setSnackbar({ open: true, message: '用户已删除。', severity: 'success' });
    } catch (error) {
      console.error('删除用户失败:', error);
      setSnackbar({ open: true, message: '删除用户失败。', severity: 'error' });
    }
  };

  return (
    <Box>
      <Button variant="contained" color="primary" onClick={() => navigate('/admin/users/create')}>
        新增用户
      </Button>

      <TableContainer component={Paper} sx={{ marginTop: 2 }}>
        <Table>
          <TableHead>
            <TableRow>
              <TableCell>用户名</TableCell>
              <TableCell>显示名</TableCell>
              <TableCell>邮箱</TableCell>
              <TableCell>电话</TableCell>
              <TableCell>部门</TableCell>
              <TableCell>角色</TableCell>
              <TableCell>操作</TableCell>
            </TableRow>
          </TableHead>
          <TableBody>
            {users.length > 0 ? (
              users.map((user) => (
                <TableRow key={user.id}>
                  <TableCell>{user.username}</TableCell>
                  <TableCell>{user.displayName}</TableCell>
                  <TableCell>{user.email}</TableCell>
                  <TableCell>{user.phone}</TableCell>
                  <TableCell>
                    {user.departments && user.departments.length > 0
                      ? user.departments.map(dept => dept.name).join(', ')
                      : '无'}
                  </TableCell>
                  <TableCell>
                    {user.roles && user.roles.length > 0
                      ? user.roles.map(role => role.name).join(', ')
                      : '无'}
                  </TableCell>
                  <TableCell>
                    <IconButton color="primary" onClick={() => navigate(`/admin/users/edit/${user.id}`)}>
                      <Edit />
                    </IconButton>
                    <IconButton color="secondary" onClick={() => handleDelete(user.id)}>
                      <Delete />
                    </IconButton>
                  </TableCell>
                </TableRow>
              ))
            ) : (
              <TableRow>
                <TableCell colSpan={7} align="center">暂无用户数据。</TableCell>
              </TableRow>
            )}
          </TableBody>
        </Table>
      </TableContainer>

      {/* Snackbar */}
      <Snackbar
        open={snackbar.open}
        autoHideDuration={6000}
        onClose={() => setSnackbar({ ...snackbar, open: false })}
        anchorOrigin={{ vertical: 'bottom', horizontal: 'center' }}
      >
        <Alert onClose={() => setSnackbar({ ...snackbar, open: false })} severity={snackbar.severity} sx={{ width: '100%' }}>
          {snackbar.message}
        </Alert>
      </Snackbar>
    </Box>
  );
};

export default UserManagement;
