import React from 'react';

const NavBar = ({ userRole }) => {
    return (
        <nav>
            {userRole === 'admin' && (
                <>
                    <a href="/departments">部门管理</a>
                    <a href="/users">用户管理</a>
                </>
            )}
            {userRole === 'user' && (
                <a href="/profile">个人信息</a>
            )}
        </nav>
    );
};

export default NavBar;
