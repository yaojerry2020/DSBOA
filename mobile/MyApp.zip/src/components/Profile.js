// src/pages/Profile.js

import React, { useState, useEffect } from 'react';
import { View, Text, TextInput, Button, Image, Alert, StyleSheet } from 'react-native';
import * as ImagePicker from 'expo-image-picker';
import api from '../api/api'; // 确保api.js配置了正确的baseURL

function Profile() {
    const [profile, setProfile] = useState({
        username: '',
        displayName: '',
        email: '',
        phone: '',
        avatar: ''
    });
    const [editMode, setEditMode] = useState(false);
    const [password, setPassword] = useState('');
    const [confirmPassword, setConfirmPassword] = useState('');
    const [passwordError, setPasswordError] = useState('');

    useEffect(() => {
        async function fetchProfile() {
            try {
                const response = await api.get('/user/profile');
                setProfile(response.data);
            } catch (error) {
                console.error("获取用户信息失败", error);
                Alert.alert("错误", "无法加载用户信息");
            }
        }
        fetchProfile();
    }, []);

    const handleInputChange = (field, value) => {
        setProfile((prevProfile) => ({ ...prevProfile, [field]: value }));
    };

    const pickImage = async () => {
        const result = await ImagePicker.launchImageLibraryAsync({
            mediaTypes: ImagePicker.MediaTypeOptions.Images,
            allowsEditing: true,
            aspect: [1, 1],
            quality: 1,
        });

        if (!result.canceled) {
            const uri = result.assets[0].uri;
            handleAvatarUpload(uri);
        }
    };

    const handleAvatarUpload = async (uri) => {
        try {
            const formData = new FormData();
            formData.append('avatar', {
                uri,
                name: 'avatar.jpg',
                type: 'image/jpeg'
            });
            const response = await api.post('/user/upload-avatar', formData, {
                headers: { 'Content-Type': 'multipart/form-data' }
            });
            setProfile((prevProfile) => ({ ...prevProfile, avatar: response.data.avatar }));
            Alert.alert("成功", "头像上传成功！");
        } catch (error) {
            console.error("头像上传失败", error);
            Alert.alert("错误", "头像上传失败");
        }
    };

    const toggleEditMode = () => {
        setEditMode(!editMode);
        setPassword('');
        setConfirmPassword('');
        setPasswordError('');
    };

    const handleSave = async () => {
        if (password && password !== confirmPassword) {
            setPasswordError('密码不一致，请重新输入');
            return;
        }
        try {
            await api.put('/user/profile', {
                email: profile.email,
                phone: profile.phone,
                password: password || undefined,
            });
            setEditMode(false);
            Alert.alert("成功", "个人信息已更新");
        } catch (error) {
            console.error("保存用户信息失败", error);
            Alert.alert("错误", "保存用户信息失败");
        }
    };

    return (
        <View style={styles.container}>
            <Text style={styles.title}>个人信息</Text>
            <Image
                source={{ uri: profile.avatar ? `${api.defaults.baseURL}${profile.avatar}` : '默认头像路径' }}
                style={styles.avatar}
            />
            {editMode && (
                <Button title="选择头像" onPress={pickImage} />
            )}
            <TextInput
                style={styles.input}
                placeholder="用户名"
                value={profile.username}
                editable={false}
            />
            <TextInput
                style={styles.input}
                placeholder="显示名"
                value={profile.displayName}
                editable={editMode}
                onChangeText={(value) => handleInputChange('displayName', value)}
            />
            <TextInput
                style={styles.input}
                placeholder="邮箱"
                value={profile.email}
                editable={editMode}
                onChangeText={(value) => handleInputChange('email', value)}
            />
            <TextInput
                style={styles.input}
                placeholder="电话"
                value={profile.phone}
                editable={editMode}
                onChangeText={(value) => handleInputChange('phone', value)}
            />
            {editMode && (
                <>
                    <TextInput
                        style={styles.input}
                        placeholder="新密码"
                        secureTextEntry
                        value={password}
                        onChangeText={(value) => setPassword(value)}
                    />
                    <TextInput
                        style={styles.input}
                        placeholder="确认新密码"
                        secureTextEntry
                        value={confirmPassword}
                        onChangeText={(value) => setConfirmPassword(value)}
                    />
                    {!!passwordError && <Text style={styles.error}>{passwordError}</Text>}
                </>
            )}
            {editMode ? (
                <View style={styles.buttonContainer}>
                    <Button title="保存修改" onPress={handleSave} />
                    <Button title="取消" color="red" onPress={toggleEditMode} />
                </View>
            ) : (
                <Button title="修改个人信息" onPress={toggleEditMode} />
            )}
        </View>
    );
}

const styles = StyleSheet.create({
    container: {
        flex: 1,
        padding: 16,
        backgroundColor: '#fff',
    },
    title: {
        fontSize: 24,
        fontWeight: 'bold',
        marginBottom: 16,
    },
    avatar: {
        width: 100,
        height: 100,
        borderRadius: 50,
        alignSelf: 'center',
        marginBottom: 16,
    },
    input: {
        borderWidth: 1,
        borderColor: '#ddd',
        padding: 8,
        borderRadius: 4,
        marginBottom: 16,
    },
    error: {
        color: 'red',
        marginBottom: 16,
    },
    buttonContainer: {
        flexDirection: 'row',
        justifyContent: 'space-between',
    },
});

export default Profile;
