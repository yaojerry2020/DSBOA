// src/contexts/AuthContext.js
import React, { createContext, useContext, useState } from 'react';
import axios from 'axios';
import Constants from 'expo-constants';
import { useNavigation } from '@react-navigation/native';

const API_URL = Constants.expoConfig?.extra?.API_URL || 'http://dsm.yaojerry.cn:4321/api';
const AuthContext = createContext();

export const AuthProvider = ({ children }) => {
    const navigation = useNavigation();
    const [user, setUser] = useState(null);
    const [error, setError] = useState(null);

    const login = async (username, password) => {
        try {
            setError(null);
            const response = await axios.post(`${API_URL}/auth/login`, { username, password });
            setUser(response.data.user);
            navigation.navigate("UserPortal"); // 登录成功后跳转
        } catch (err) {
            setError("登录失败，请检查用户名或密码");
            console.error("登录请求失败:", err);
        }
    };

    const logout = () => {
        setUser(null);
        navigation.navigate("Login"); // 登出后跳转
    };

    return (
        <AuthContext.Provider value={{ user, login, logout, error }}>
            {children}
        </AuthContext.Provider>
    );
};

export const useAuth = () => useContext(AuthContext);
